const UI = {
    showMenu() {
        document.getElementById('menu-overlay').classList.add('active');
    },
    
    closeMenu() {
        document.getElementById('menu-overlay').classList.remove('active');
    },
    
    closeMenuIfOutside(event) {
        if (event.target.id === 'menu-overlay') {
            this.closeMenu();
        }
    },
    
    renderCategoriesList(categories) {
        const container = document.getElementById('categories-list');
        const select = document.getElementById('item-category');
        
        container.innerHTML = '';
        select.innerHTML = '<option value="">Select category...</option>';
        
        categories.forEach(category => {
            // Update select dropdown
            const option = document.createElement('option');
            option.value = category.id;
            option.textContent = category.name;
            select.appendChild(option);
            
            // Create category card
            const card = document.createElement('div');
            card.className = 'category-card';
            card.style.borderLeftColor = category.color;
            
            const totalItems = categories.reduce((sum, cat) => sum + cat.items.length, 0);
            const autoPercentage = totalItems > 0 
                ? ((category.items.length / totalItems) * 100).toFixed(1)
                : '0.0';
            
            const itemsHTML = category.items.length > 0
                ? `<div class="items-in-category">
                    ${category.items.map(item => `
                        <div class="item-card" style="border-left-color: ${item.color}">
                            <h3>${item.name}</h3>
                            <div class="percentage">${item.percentage.toFixed(1)}% of category</div>
                            ${item.subItems.length > 0 
                                ? `<ul>${item.subItems.map((sub, idx) => `
                                    <li>
                                        <span class="sub-item-text">${sub}</span>
                                        <button class="small" onclick="App.removeSubItem('${category.id}', '${item.id}', ${idx})">✕</button>
                                    </li>
                                `).join('')}</ul>`
                                : '<p style="color: #999; font-size: 12px;">No sub-items</p>'}
                            <button onclick="App.removeItem('${category.id}', '${item.id}')">Remove Item</button>
                        </div>
                    `).join('')}
                   </div>`
                : '<div class="empty-category">No items yet</div>';
            
            card.innerHTML = `
                <div class="category-header">
                    <div>
                        <h2>${category.name}</h2>
                        <div class="auto-percentage">${autoPercentage}% (${category.items.length} items)</div>
                    </div>
                    <button onclick="App.removeCategory('${category.id}')">Remove Category</button>
                </div>
                ${itemsHTML}
            `;
            
            container.appendChild(card);
        });
    },
    
    clearInputs() {
        document.getElementById('item-name').value = '';
        document.getElementById('item-percentage').value = '';
        document.getElementById('sub-items').value = '';
        document.getElementById('item-category').value = '';
        document.getElementById('item-color').value = this.getRandomColor();
    },
    
    clearCategoryInputs() {
        document.getElementById('new-category-name').value = '';
        document.getElementById('new-category-color').value = this.getRandomColor();
    },
    
    getRandomColor() {
        const colors = ['#4CAF50', '#2196F3', '#FF9800', '#E91E63', '#9C27B0', '#00BCD4', '#FFEB3B', '#FF5722', '#795548', '#607D8B'];
        return colors[Math.floor(Math.random() * colors.length)];
    }
};