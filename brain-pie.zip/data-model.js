const DataModel = {
    categories: [
        { id: 'car', name: 'Car', color: '#FF6B6B', items: [] },
        { id: 'house', name: 'House', color: '#4ECDC4', items: [] },
        { id: 'admin', name: 'Admin', color: '#45B7D1', items: [] },
        { id: 'people', name: 'People', color: '#FFA07A', items: [] }
    ],
    
    loadFromStorage() {
        const data = Storage.load();
        if (data && data.categories) {
            this.categories = data.categories;
        }
    },
    
    saveToStorage() {
        Storage.save({ categories: this.categories });
    },
    
    addCategory(name, color) {
        const id = name.toLowerCase().replace(/\s+/g, '-') + '-' + Date.now();
        this.categories.push({
            id,
            name,
            color,
            items: []
        });
        this.saveToStorage();
        return id;
    },
    
    removeCategory(categoryId) {
        this.categories = this.categories.filter(cat => cat.id !== categoryId);
        this.saveToStorage();
    },
    
    addItem(categoryId, name, percentage, color, subItems) {
        const category = this.categories.find(cat => cat.id === categoryId);
        if (!category) return null;
        
        const id = Date.now().toString();
        category.items.push({
            id,
            name,
            percentage,
            color,
            subItems: subItems || []
        });
        
        this.normalizeItemsInCategory(categoryId);
        this.saveToStorage();
        return id;
    },
    
    removeItem(categoryId, itemId) {
        const category = this.categories.find(cat => cat.id === categoryId);
        if (!category) return;
        
        category.items = category.items.filter(item => item.id !== itemId);
        this.normalizeItemsInCategory(categoryId);
        this.saveToStorage();
    },
    
    removeSubItem(categoryId, itemId, subItemIndex) {
        const category = this.categories.find(cat => cat.id === categoryId);
        if (!category) return;
        
        const item = category.items.find(i => i.id === itemId);
        if (!item) return;
        
        item.subItems.splice(subItemIndex, 1);
        this.saveToStorage();
    },
    
    normalizeItemsInCategory(categoryId) {
        const category = this.categories.find(cat => cat.id === categoryId);
        if (!category || category.items.length === 0) return;
        
        const total = category.items.reduce((sum, item) => sum + item.percentage, 0);
        if (total > 0 && total !== 100) {
            category.items.forEach(item => {
                item.percentage = (item.percentage / total) * 100;
            });
        }
    },
    
    getCategories() {
        return this.categories;
    },
    
    setCategories(categories) {
        this.categories = categories;
        this.saveToStorage();
    }
};