const ChartRenderer = {
    svg: null,
    width: 1800,
    height: 1200,
    outerRadius: 550,
    innerRadius: 500,
    
    init(containerId) {
        const container = d3.select(`#${containerId}`);
        container.selectAll('*').remove();
        
        this.svg = container.append('svg')
            .attr('width', this.width)
            .attr('height', this.height)
            .append('g')
            .attr('transform', `translate(${this.width / 2}, ${this.height / 2})`);
    },
    
    render(categories) {
        if (!this.svg) this.init('chart-container');
        
        this.svg.selectAll('*').remove();
        
        const totalItems = categories.reduce((sum, cat) => sum + cat.items.length, 0);
        
        if (totalItems === 0) {
            this.svg.append('text')
                .attr('text-anchor', 'middle')
                .attr('fill', '#999')
                .attr('font-size', '16px')
                .text('Add items to see your brain pie chart');
            return;
        }
        
        // Calculate category percentages based on item count
        const categoryData = categories.map(cat => ({
            ...cat,
            percentage: (cat.items.length / totalItems) * 100
        })).filter(cat => cat.items.length > 0);
        
        // Outer ring (categories)
        const outerPie = d3.pie()
            .value(d => d.percentage)
            .sort(null);
        
        const outerArc = d3.arc()
            .innerRadius(this.innerRadius)
            .outerRadius(this.outerRadius);
        
        const categoryLabelArc = d3.arc()
            .innerRadius(this.outerRadius + 40)
            .outerRadius(this.outerRadius + 40);
        
        const outerData = outerPie(categoryData);
        
        // Draw outer category slices
        const categorySlices = this.svg.selectAll('.outer-slice')
            .data(outerData)
            .enter()
            .append('g')
            .attr('class', 'outer-slice');
        
        categorySlices.append('path')
            .attr('d', outerArc)
            .attr('fill', d => d.data.color)
            .attr('stroke', 'white')
            .attr('stroke-width', 3)
            .attr('opacity', 0.7);
        
        // Category labels
        categorySlices.append('text')
            .attr('class', 'category-label')
            .attr('transform', d => {
                const pos = categoryLabelArc.centroid(d);
                return `translate(${pos})`;
            })
            .attr('text-anchor', 'middle')
            .text(d => d.data.name);
        
        categorySlices.append('text')
            .attr('class', 'category-percentage')
            .attr('transform', d => {
                const pos = categoryLabelArc.centroid(d);
                pos[1] += 20;
                return `translate(${pos})`;
            })
            .attr('text-anchor', 'middle')
            .text(d => `${d.data.percentage.toFixed(1)}%`);
        
        // Inner ring (items within categories)
        outerData.forEach(catData => {
            const category = catData.data;
            const items = category.items;
            
            if (items.length === 0) return;
            
            const categoryStartAngle = catData.startAngle;
            const categoryEndAngle = catData.endAngle;
            
            // Create pie for items within this category's angle range
            const itemPie = d3.pie()
                .value(d => d.percentage)
                .sort(null)
                .startAngle(categoryStartAngle)
                .endAngle(categoryEndAngle);
            
            const innerArc = d3.arc()
                .innerRadius(0)
                .outerRadius(this.innerRadius);
            
            const itemLabelArc = d3.arc()
                .innerRadius(this.innerRadius / 2)
                .outerRadius(this.innerRadius / 2);
            
            const itemData = itemPie(items);
            
            // Draw item slices
            const itemSlices = this.svg.selectAll(`.inner-slice-${category.id}`)
                .data(itemData)
                .enter()
                .append('g')
                .attr('class', `inner-slice inner-slice-${category.id}`);
            
            itemSlices.append('path')
                .attr('d', innerArc)
                .attr('fill', d => d.data.color)
                .attr('stroke', 'white')
                .attr('stroke-width', 2);
            
            // Item labels (for items with enough space)
            itemSlices.filter(d => (d.endAngle - d.startAngle) > 0.25)
                .append('text')
                .attr('class', 'item-label')
                .attr('transform', d => {
                    const pos = itemLabelArc.centroid(d);
                    return `translate(${pos})`;
                })
                .attr('text-anchor', 'middle')
                .text(d => d.data.name);
            
            // Draw sub-items - EXTENDING PAST OUTER RING
            itemSlices.each((d, i, nodes) => {
                const group = d3.select(nodes[i]);
                const subItems = d.data.subItems;
                
                if (subItems.length === 0) return;
                
                const startAngle = d.startAngle;
                const endAngle = d.endAngle;
                const angleStep = (endAngle - startAngle) / subItems.length;
                
                subItems.forEach((subItem, idx) => {
                    const angle = startAngle + (angleStep * (idx + 0.5));
                    const innerX = 0;
                    const innerY = 0;
                    
                    // Extend line through inner ring, through outer ring, and beyond
                    const throughInnerX = Math.cos(angle - Math.PI / 2) * this.innerRadius;
                    const throughInnerY = Math.sin(angle - Math.PI / 2) * this.innerRadius;
                    const throughOuterX = Math.cos(angle - Math.PI / 2) * this.outerRadius;
                    const throughOuterY = Math.sin(angle - Math.PI / 2) * this.outerRadius;
                    const extendX = Math.cos(angle - Math.PI / 2) * (this.outerRadius + 30);
                    const extendY = Math.sin(angle - Math.PI / 2) * (this.outerRadius + 30);
                    
                    // Draw line from center through both rings
                    group.append('line')
                        .attr('class', 'sub-item-line')
                        .attr('x1', innerX)
                        .attr('y1', innerY)
                        .attr('x2', extendX)
                        .attr('y2', extendY);
                    
                    // Draw horizontal line to label
                    const horizontalLength = 35;
                    const direction = extendX > 0 ? 1 : -1;
                    group.append('line')
                        .attr('class', 'sub-item-line')
                        .attr('x1', extendX)
                        .attr('y1', extendY)
                        .attr('x2', extendX + (horizontalLength * direction))
                        .attr('y2', extendY);
                    
                    // Add label
                    group.append('text')
                        .attr('class', 'sub-item-label')
                        .attr('x', extendX + ((horizontalLength + 5) * direction))
                        .attr('y', extendY + 4)
                        .attr('text-anchor', extendX > 0 ? 'start' : 'end')
                        .text(subItem);
                });
            });
        });
    }
};